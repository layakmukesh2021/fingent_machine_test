<!DOCTYPE html>
<html>
<head>




<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
  overflow:scroll;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}


.button {
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}

.button1 {background-color: #4CAF50;} /* Green */
.button2 {background-color: #008CBA;} /* Blue */



</style>
</head>
<body>


<a href="<?php echo site_url('SiteController/home');?>"  class="button button1" >Home</a>  

<?php echo form_open_multipart('SiteController/add_bill');?>  

<h2 style="text-align: center;color: #000000">BILL</h2>
<center>


<table class="col-md-8">

  <tr>

    <th>Sl No</th>
    <th>Product Name</th>
    <th>Quantity</th>
    <th>Unit Price</th>
    <th>Total Amount</th>
   
  </tr>


<tbody>


  <tr>
    <td>1</td>
    <td> 
     <div class="form-group" style="margin-top: 16px;">
                    <label class="control-label no-padding-right"></label>

                    <div class="">
                      <div class="pos-rel">
                      
                      <select name="prdt_name" class="form-control" id="prdt_name" onchange="prdt_change(this.value);">
                      <option value="">Select Product</option>
                      <?php
                      foreach($subcat_list as $subcat)
                      {?>
                        <option value="<?php echo $subcat['id']?>" <?php echo set_select('prdt_name',$subcat['id']);?>><?php echo $subcat['prdt_name']?></option>
                      <?php } ?>
                      </select>
                      <div style="color:red"><?php echo form_error('prdt_name');?></div>
                      </div>
                    </div>
                  </div></td>
    <td><input type="number" name="quantity" id="quantity"  value="1" style="height: 37px;width:66px;" onkeyup="calculation()"></td>
    <td id="amount_div" ><input type="text" name="unit_price" id="unit_price" style="background-color: #e5ecf3;height: 37px;">
    </td>
    <td><input type="text" name="total_price" id="total_price" style="background-color: #e5ecf3;height: 37px;">
  
  
  </tr>
  </tbody>


</table>
<br/>
<div class="col-md-8">
 <input type="submit" name="add" id="add" class="btn btn-primary" value="+" style="width: 50px;float: right;">

</div>
</center>

</form>

<br/><br/>

<h2 style="text-align: center;color: #000000">BILL DETAILS</h2>
<center>


<?php echo form_open_multipart('SiteController/select_invoice');?>  



<table class="col-md-8">

  <tr>

    <th>Sl No</th>
    <th>Product Name</th>
    <th>Quantity</th>
    <th>Unit Price($)</th>
    <th>Tax(%)</th>
    <th>Total Amount($)</th>
    <th>Amount Without Tax($)</th>
    <th>Amount With Tax($)</th>

   
  </tr>


<tbody>


<?php
  if(count($details)==0){

    ?>
                      <tr>
                      <td colspan="8" style="color:red" align="center"><h3>No data found</h3></td>
                      </tr>
                      <?php
                     }

                    $i=1;

                    $grandtotal=0;
                     $billnumber=0;
                     foreach($details as $rows)
                     {


                       $id=$rows['id'];
                       $prdt_name=$rows['prdt_name'];
                       $prdt_quantity=$rows['quantity'];
                       $unit_price=$rows['unit_price'];
                       $tax_percentage=$rows['tax'];
                       $total_price=$rows['total_price'];
                       $product_name=$rows['product_name'];



                       $billnumber=$rows['bill_no'];


                       $without_tax=$total_price;

                       $tax_amont=($total_price*$tax_percentage)/100;
                       $with_tax=$total_price+$tax_amont;


                       $grandtotal+=$with_tax;


                     ?>
  <tr>

    <td><?php echo $i; ?> </td>
    <td><?php echo $prdt_name; ?> </td>
    <td><?php echo $prdt_quantity; ?> </td>
    <td><?php echo $unit_price; ?> </td>
    <td><?php echo $tax_percentage; ?> </td>
    <td><?php echo $total_price; ?> </td>
    <td><?php echo $without_tax; ?> </td>
    <td><?php echo $with_tax; ?> </td>
  
  </tr>


<?php
$i++;
}

?>

</tbody>


<tfoot>

  <tr>
    <td colspan="7" style="text-align: right;">Grand Total</td>
    <td><input type="text" class="form-control" name="grandtotal" id="grandtotal" value="<?php echo $grandtotal;?>" >
</td>
  </tr>
 <tr>
    <td colspan="6" style="text-align: right;">Discount Type</td>
    <td style="text-align: right;">
   <select name="discount" id="discount" class="form-control" onkeyup="discountvalue()">
    <option value="">Select Discount Type</option>
    <option value="Amount">Amount(In $)</option>
    <option value="Percentage">Amount(In %)</option>
   </select></td>
    <td style="text-align: right;"><input type="text" class="form-control" name="dis_count" id="dis_count" onkeyup="discountvalue()"></td>
    
  </tr>

  <tr>
    <td colspan="7" style="text-align: right;">Net Amount</td>
    <td><input type="text" class="form-control" name="net_total" id="net_total">
    </td>
  </tr>

 <input type="hidden" class="form-control" name="billno" id="billno" value="<?php echo 
 $billnumber;?>" > 

</tfoot>


</table>



<br/>
<div class="col-md-8">
 <input type="submit" name="gen_invoice" id="gen_invoice" class="btn btn-primary" value="Generate Invoice" style="width: 200px;float: right;">

</div>


</center>
</form>

</body>
</html>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>


<script type="text/javascript">
  


  function prdt_change(parent)
    {
      
    var prdt_name=document.getElementById('prdt_name').value;
  //alert(prdt_name);
   
    $.ajax({
      type: "POST",
      url:'<?php echo site_url('SiteController/sel_price/')?>'+parent,
       data:{prdt_name:prdt_name},
      success: function(data) {
        
        $("#amount_div").html(data);

        calculation();
       // show_hide_div(parent);
            },
        });
    }




  function calculation(parent)
    {
      
    var unit_price=document.getElementById('unit_price').value;

    var tax=document.getElementById('tax').value;
    
    var quantity=document.getElementById('quantity').value;

    var sub_total_price=parseInt(unit_price)*parseInt(quantity);

   //alert(sub_total_price);
    document.getElementById('total_price').value = sub_total_price;

    }



  function discountvalue(parent)
    {
      

    //  alert("gdfg");
    var grand_total=document.getElementById('grandtotal').value;

    var discount=document.getElementById('discount').value;
    
    var dis_count=document.getElementById('dis_count').value;

//alert(grand_total);
//alert(discount);
//alert(dis_count);

if(discount=="Amount")
{
  var net_total=parseInt(grand_total)-parseInt(dis_count);
}
else if(discount=="Percentage")
{

  var amnt=(parseInt(grand_total)*parseInt(dis_count))/100;

  var net_total=parseInt(grand_total)-parseInt(amnt);

}


   // var sub_total_price=parseInt(unit_price)*parseInt(quantity);

   //alert(sub_total_price);
    document.getElementById('net_total').value = net_total;

    }




//    function generat_invoice(id)
//     {


// var grandtotal=document.getElementById('grandtotal').value;
// var discount=document.getElementById('discount').value;
// var dis_count=document.getElementById('dis_count').value;
// var net_total=document.getElementById('net_total').value;
// var billno=document.getElementById('billno').value;


// if(net_total!=""){
//      $.ajax({
//         type:'post',
//         url:'<?php echo site_url('SiteController/select_invoice/')?>'+id,
//         data:{grandtotal:grandtotal,discount:discount,dis_count:dis_count,net_total:net_total,billno:billno},
       // dataType:'json', 
       // success: function(data){
       
           // location.reload();

          // alert(data);

          // window.location.href = "bill_invoice.php";

           
       //   },
        
      
      //  });
//}

     
    
 // }






</script>

