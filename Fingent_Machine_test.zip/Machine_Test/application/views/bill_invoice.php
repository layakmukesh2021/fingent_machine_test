<style type="text/css">
	
/* reset */

*
{
	border: 0;
	box-sizing: content-box;
	color: inherit;
	font-family: inherit;
	font-size:16px;
	font-style: inherit;
	font-weight: inherit;
	line-height: inherit;
	list-style: none;
	margin: 0;
	padding: 0;
	text-decoration: none;
	vertical-align: top;
}

/* content editable */

*[contenteditable] { border-radius: 0.25em; min-width: 1em; outline: 0; }

*[contenteditable] { cursor: pointer; }

*[contenteditable]:hover, *[contenteditable]:focus, td:hover *[contenteditable], td:focus *[contenteditable], img.hover { background: #DEF; box-shadow: 0 0 1em 0.5em #DEF; }

span[contenteditable] { display: inline-block; }

/* heading */

h1 { font: bold 100% sans-serif; letter-spacing: 0.5em; text-align: center; text-transform: uppercase; }


#spcolr
{
font: bold 100% sans-serif;  text-align: center; text-transform: uppercase;font-size: 12px;	
}

/* table */

table { font-size: 75%; table-layout: fixed; width: 100%; }
table { border-collapse: separate; border-spacing: 2px; }
th, td { border-width: 1px; padding: 0.5em; position: relative; text-align: left; }
th, td { border-radius: 0.25em; border-style: solid; }
th { background: #EEE; border-color: #BBB; }
td { border-color: #DDD; }

/* page */

html { font: 16px/1 'Open Sans', sans-serif; overflow: auto; padding: 0.5in; }
html { background: #d5efec; cursor: default; }

body { box-sizing: border-box; height: 11in; margin: 0 auto; overflow: hidden; padding: 0.5in; width: 8.5in; }
body { background: #FFF; border-radius: 1px; box-shadow: 0 0 1in -0.25in rgba(0, 0, 0, 0.5); }

/* header */

header { margin: 0 0 3em; }
header:after { clear: both; content: ""; display: table; }

header h1 { background: #000; border-radius: 0.25em; color: #FFF; margin: 0 0 1em; padding: 0.5em 0; }
header address { float: left; font-size: 75%; font-style: normal; line-height: 1.25; margin: 0 1em 1em 0; }
header address p { margin: 0 0 0.25em; }
header span, header img { display: block; float: right; }
header span { margin: 0 0 1em 1em; max-height: 25%; max-width: 60%; position: relative; }
header img { max-height: 100%; max-width: 100%; }
header input { cursor: pointer; -ms-filter:"progid:DXImageTransform.Microsoft.Alpha(Opacity=0)"; height: 100%; left: 0; opacity: 0; position: absolute; top: 0; width: 100%; }

/* article */

article, article address, table.meta, table.inventory { margin: 0 0 3em; }
article:after { clear: both; content: ""; display: table; }
article h1 { clip: rect(0 0 0 0); position: absolute; }

article address { float: left; font-size: 125%; font-weight: bold; }

/* table meta & balance */

table.meta, table.balance { float: right; width: 36%; }
table.meta:after, table.balance:after { clear: both; content: ""; display: table; }

/* table meta */

table.meta th { width: 40%; }
table.meta td { width: 60%; }

/* table items */

table.inventory { clear: both; width: 100%; }
table.inventory th { font-weight: bold; text-align: center; }

table.inventory td:nth-child(1) { width: 26%; }
table.inventory td:nth-child(2) { width: 38%; }
table.inventory td:nth-child(3) { text-align: right; width: 12%; }
table.inventory td:nth-child(4) { text-align: right; width: 12%; }
table.inventory td:nth-child(5) { text-align: right; width: 12%; }

/* table balance */

table.balance th, table.balance td { width: 50%; }
table.balance td { text-align: right; }

/* aside */

aside h1 { border: none; border-width: 0 0 1px; margin: 0 0 1em; }
aside h1 { border-color: #999; border-bottom-style: solid; }

/* javascript */

.add, .cut
{
	border-width: 1px;
	display: block;
	font-size: .8rem;
	padding: 0.25em 0.5em;	
	float: left;
	text-align: center;
	width: 0.6em;
}

.add, .cut
{
	background: #9AF;
	box-shadow: 0 1px 2px rgba(0,0,0,0.2);
	background-image: -moz-linear-gradient(#00ADEE 5%, #0078A5 100%);
	background-image: -webkit-linear-gradient(#00ADEE 5%, #0078A5 100%);
	border-radius: 0.5em;
	border-color: #0076A3;
	color: #FFF;
	cursor: pointer;
	font-weight: bold;
	text-shadow: 0 -1px 2px rgba(0,0,0,0.333);
}

.add { margin: -2.5em 0 0; }

.add:hover { background: #00ADEE; }

.cut { opacity: 0; position: absolute; top: 0; left: -1.5em; }
.cut { -webkit-transition: opacity 100ms ease-in; }

tr:hover .cut { opacity: 1; }

@media print {
	* { -webkit-print-color-adjust: exact; }
	html { background: none; padding: 0; }
	body { box-shadow: none; margin: 0; }
	span:empty { display: none; }
	.add, .cut { display: none; }
}

@page { margin: 0; }




</style>





<html>
	<head>
		<meta charset="utf-8">
		<title>Bill Invoice</title>
		<link rel="stylesheet" href="style.css">
		<link rel="license" href="https://www.opensource.org/licenses/mit-license/">
		<script src="script.js"></script>
	</head>
	<body>


		 <script type="text/javascript">

window.onload = function() { window.print(); }

</script> 


<div style="float: right;">
<!-- <button style="height: 27px;width: 111px;background-color: #159b8b;border: 1px solid #1b554e;" 
id="genpdf" onclick="CreatePDFfromHTML()"> Generate PDF </button> -->


<!-- <button style="height: 27px;width: 111px;background-color: #159b8b;border: 1px solid #1b554e;" 
id="genpdf" onclick="printDiv1(div1)" > Print </button> -->
 

<!-- <a href="#"  onclick="printDiv(div1);" style="height: 30px;width: 111px;background-color: #159b8b;border: 1px solid #1b554e;color: #ffffff;text-decoration: none;">Print Page</a> -->



</div>

<div id="div1" style="margin-top: 60px">
		<header>
			<!-- <img src="assets/images/logo.jpg"> -->
<h2 style="text-align: center;">Comapny Logo</h2>
<br/>
				<div  id="spcolr">Address<br/>Phone Number</div>
	
			<br/><br/>

		
			<span><img alt="" src="http://www.jonathantneal.com/examples/invoice/logo.png"><input type="file" accept="image/*"></span>
		</header>
		<article>
			<h1>Recipient</h1>
<?php

  foreach($invoice as $rows)
                     {



                       $billnumber=$rows['bill_no'];

                       $created_date=$rows['created_date'];

                       $grand_total=$rows['grand_total'];
                       $discount=$rows['discount'];
                       $net_total=$rows['net_total'];



}

 ?>



			
			<table class="meta">
				<tr>
					<th><span>Bill No</span></th>
					<td><span><?php echo  $billnumber;?></span></td>
				</tr>
				<tr>
					<th><span>Date</span></th>
					<td><span><?php echo date('d-m-Y',strtotime($created_date)) ?></span></td>
				</tr>
			
			</table>
			<table class="inventory">
				<thead>
					<tr>
						<th style="width: 25px;"><span>SlNo</span></th>
						<!-- <th><span>Item Code</span></th> -->
						<th><span>Item Name</span></th>
						<th><span>Rate</span></th>
						<th><span>Quantity</span></th>
						<th><span>Total</span></th>
					</tr>
				</thead>




				<tbody>
					

<?php
 $i=1;
 $totalamnt=0;
  foreach($product_in as $row)
                     {

 $product_name=$row['prdt_name'];

 $unit_price=$row['unit_price'];
 $quantity=$row['quantity'];
 $total_price=$row['total_price'];

 $totalamnt+=$total_price; 



 $taxamnt=$grand_total-$totalamnt;
 

?>

<tr>
						<td><span><?php echo $i;?></span></td>
						<!-- <td style="text-align: right;"><span><?php echo $prdt_name;?></span></td> -->
						<td><span><?php echo $product_name;?></span></td>
						<td><span><?php echo $unit_price;?></span></td>
						<td><span><?php echo $quantity;?></span></td>
						<td style="text-align: right;"><span><?php echo $total_price;?></span></td>

</tr>
<?php

$i++;
}
?>

					
				</tbody>





			</table>
			
			<table class="balance">



				<tr>
					<th><span>Total Amount($)</span></th>
					<td><span><?php echo $totalamnt;?></span></td>
				</tr>
				<tr>
					<th><span>Tax Amount($)</span></th>
					<td><span><?php echo $taxamnt;?></span></td>
				</tr>
				<tr>
					<th><span>Grand Total($)</span></th>
					<td><span><?php echo $grand_total;?></span></td>
				</tr>

				<tr>
					<th><span>Discount</span></th>
					<td><span><?php echo $discount;?></span></td>
				</tr>

				<tr>
					<th><span>Net Amount($)</span></th>
					<td><span><?php echo $net_total;?></span></td>
				</tr>
			

				<tr><td style="padding-top: 40px;border: none;">
					
					Signature : </td>
				</tr>
			</table>


		</article>
		<aside>
			<h1><span>Additional Notes</span></h1>
			<div>
				<p>Additional Informations  can write here.</p>
			</div>
		</aside>

	</div>




	</body>
</html>



<?php

//}
?>


<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>



<!-- Script for pdf start-->

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.5.3/jspdf.min.js"></script>
<script type="text/javascript" src="https://html2canvas.hertzen.com/dist/html2canvas.js"></script>

<script type="text/javascript">
  
function CreatePDFfromHTML() {
    var HTML_Width = $("#div1").width();
    var HTML_Height = $("#div1").height();
    var top_left_margin = 20;
    var PDF_Width = HTML_Width + (top_left_margin * 2);
    var PDF_Height = (PDF_Width * 1.5) + (top_left_margin * 2);
    var canvas_image_width = HTML_Width;
    var canvas_image_height = HTML_Height;

    var totalPDFPages = Math.ceil(HTML_Height / PDF_Height) - 1;

    html2canvas($("#div1")[0]).then(function (canvas) {
        var imgData = canvas.toDataURL("image/jpeg", 1.0);
        var pdf = new jsPDF('p', 'pt', [PDF_Width, PDF_Height]);
        pdf.addImage(imgData, 'JPG', top_left_margin, top_left_margin, canvas_image_width, canvas_image_height);
        for (var i = 1; i <= totalPDFPages; i++) { 
            pdf.addPage(PDF_Width, PDF_Height);
            pdf.addImage(imgData, 'JPG', top_left_margin, -(PDF_Height*i)+(top_left_margin*4),canvas_image_width,canvas_image_height);
        }
        pdf.save("momentscloud_invoice.pdf");
        //$("#div1").hide();
    });
}

</script>

<script type="text/javascript">
function printDiv() 
{

  var divToPrint=document.getElementById('div1');

  var newWin=window.open('','Print-Window');

  newWin.document.open();

  newWin.document.write('<html><body onload="window.print()">'+div1.innerHTML+'</body></html>');

  newWin.document.close();

  setTimeout(function(){newWin.close();},10);


}
</script>

<!--End-->


