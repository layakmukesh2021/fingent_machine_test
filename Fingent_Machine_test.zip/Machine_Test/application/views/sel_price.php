	
		<?php
		foreach($product as $cat)
		{
			?>
		
 <input type="text" name="unit_price" id="unit_price" value="<?php echo $cat->unit_price;?>" style="background-color: #e5ecf3;height: 37px;">

 <input type="hidden" name="tax" id="tax" value="<?php echo $cat->tax_percentage;?>" style="background-color: #e5ecf3;height: 37px;">

		<?php } ?>