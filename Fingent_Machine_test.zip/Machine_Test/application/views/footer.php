
    <!-- JS -->
    <script src="<?php echo base_url();?>assets/vendor/jquery/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/nouislider/nouislider.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/wnumb/wNumb.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/jquery-validation/dist/jquery.validate.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/jquery-validation/dist/additional-methods.min.js"></script>

      <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
      <script src="<?php echo base_url();?>assets/js/bootstrap-select.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <script src="<?php echo base_url();?>assets/js/main.js"></script>
</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>