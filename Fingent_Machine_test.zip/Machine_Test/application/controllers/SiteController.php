<?php
//ob_start();
//session_start();
defined('BASEPATH') OR exit('No direct script access allowed');

class SiteController extends CI_Controller{

function __construct(){

parent::__construct();  

$this->load->model('Sitemodel');  
$this->load->library('email');
$this->load->library('pagination');
$this->load->library('encryption');
$this->load->helper('url');  
$this->load->library('session');
$this->load->helper('form');  

}


public function index(){



$dis['val']=$this->Sitemodel->display_data();
     


{
           //$this->load->view('header');
//$this->load->view('viewpage',$dis);
//$this->load->view('footer');

  $this->load->view('loginpage',$dis);
}



}



  public function sel_price($channel){
      
      $prdt_name=$this->input->post('prdt_name');

      // echo  $prdt_name;
      // exit;
      
      $data['product'] = $this->Sitemodel->get_product_price($prdt_name);

      $this->load->view('sel_price',$data);

    }




  // public function sel_total_price($channel){
      
  //     $sub_total_price=$this->input->post('sub_total_price');

  
  //     $data['product'] = $this->Sitemodel->get_product_total_price($sub_total_price);

  //     $this->load->view('sel_total_price',$sub_total_price);

  //   }


public function home()
{


$this->load->view('header');
$this->load->view('viewpage');
$this->load->view('footer');

}

public function add()
       {


$this->load->view('header');
$this->load->view('addproduct');
$this->load->view('footer');

}






public function addproducts()
{

  $dis['val']=$this->Sitemodel->display_data();
  $this->load->view('header');
  $this->load->view('view_product',$dis);
  $this->load->view('footer');

}



public function products_reg()
{


$this->load->view('header');
$this->load->view('addproduct');
$this->load->view('footer');

}

public function generatebill()
{

$dis['subcat_list'] = $this->Sitemodel->get_product_lists();
$dis['details'] = $this->Sitemodel->get_product_details();
$this->load->view('header');
$this->load->view('generate_bill',$dis);
$this->load->view('footer');

}



public function adddetails()
{

// echo "dhdh";
// exit;


$this->form_validation->set_rules('name','name','required|trim|xss_clean',array('required'=>'Please enter product name'));
$this->form_validation->set_rules('qty','qty','required|trim|xss_clean',array('required'=>'Please enter quantity'));


$this->form_validation->set_rules('unitprice','unitprice','required|trim|numeric|xss_clean',array('required'=>'Please enter unit price'));

$this->form_validation->set_rules('tax','tax','required|trim|xss_clean',array('required'=>'Please enter tax percentage'));



     if($this->form_validation->run() == TRUE)
{




   $data=array(



      'prdt_name'=>$this->input->post('name'),
      'prdt_quantity'=>$this->input->post('qty'),
      'unit_price'=>$this->input->post('unitprice'),
      'tax_percentage'=>$this->input->post('tax'),
     

 
);
   $re=$this->Sitemodel->add_details($data);


if($re==true)
{
 

$dis['val']=$this->Sitemodel->display_data();
  $this->load->view('header');
  $this->load->view('view_product',$dis);
  $this->load->view('footer');

}
   
}
else
{
//$dis['val']=$this->Sitemodel->display_data();
$this->load->view('header');
$this->load->view('addproduct');
$this->load->view('footer');

}






}







public function add_bill()
{

// echo "dhdh";
// exit;


$binnno=$this->Sitemodel->get_lastbill_no();

if($binnno['maxcode']==NULL)
        {

          $billnum ='100';

        }
        elseif($binnno['maxcode']!="")
        {
          
          $billnum  = $binnno['maxcode']+1;

        }


$this->form_validation->set_rules('prdt_name','prdt_name','required|trim|xss_clean',array('required'=>'Please enter product name'));

     if($this->form_validation->run() == TRUE)
{

   $data=array(



      'product_name'=>$this->input->post('prdt_name'),
      'quantity'=>$this->input->post('quantity'),
      'unit_price'=>$this->input->post('unit_price'),
      'tax'=>$this->input->post('tax'),
      'total_price'=>$this->input->post('total_price'),
      'bill_no'=>$billnum,


 
);
   $re=$this->Sitemodel->add_bill_details($data);


if($re==true)
{
 
 
$dis['subcat_list'] = $this->Sitemodel->get_product_lists();

$dis['details'] = $this->Sitemodel->get_product_details();

  $this->load->view('header');
  $this->load->view('generate_bill',$dis);
  $this->load->view('footer');

}
   
}
else
{
$dis['subcat_list'] = $this->Sitemodel->get_product_lists();
$dis['details'] = $this->Sitemodel->get_product_details();
$this->load->view('header');
$this->load->view('generate_bill',$dis);
$this->load->view('footer');

}

}






public function select_invoice()
{


$bill_num=$this->input->post('billno');

$this->form_validation->set_rules('grandtotal','grandtotal','required|trim|xss_clean',array('required'=>'Please enter product name'));

     if($this->form_validation->run() == TRUE)
{

   $data=array(


      'bill_no'=>$this->input->post('billno'),
      'discount_type'=>$this->input->post('discount'),
      'discount'=>$this->input->post('dis_count'),
      'grand_total'=>$this->input->post('grandtotal'),
      'net_total'=>$this->input->post('net_total'),
      
 
);


   $res=$this->Sitemodel->update_invoice_details();

   $re=$this->Sitemodel->add_invoice_details($data);


if($re==true && $res==true)
{
 


  $dis['invoice'] = $this->Sitemodel->get_bill_invoice_details();

  $dis['product_in'] = $this->Sitemodel->get_pro_invoice_details($bill_num);


  $this->load->view('header');
  $this->load->view('bill_invoice',$dis);
  $this->load->view('footer');

}
   
}
else
{

$dis['subcat_list'] = $this->Sitemodel->get_product_lists();
$dis['details'] = $this->Sitemodel->get_product_details();
$this->load->view('header');
$this->load->view('generate_bill',$dis);
$this->load->view('footer');

}

}








function upload_file1($field_name){
 // http://localhost/sinsi/oryxshopee/uploads/1524205224.jpg
$config['upload_path']  = './uploads/';

$config['allowed_types'] = 'gif|jpg|png';
$config['file_name']     = 'new'.substr(md5(rand()),0,5);
//$config['max_size']             = 0;
//$config['width']            = 1024;
//$config['height']           = 768;
$config['encrypt_name']           = FALSE;
$config['overwrite']           = FALSE;

$this->load->library('upload', $config);
         $this->upload->initialize($config);
if ( ! $this->upload->do_upload($field_name))
{
echo $this->upload->display_errors();
$this->session->set_flashdata('message', $this->upload->display_errors('', ''));
//redirect('profile');
return false;
}
else
{

$upload_data = $this->upload->data();
        $file_name = $upload_data['file_name']  ;  
  $this->load->library('image_lib');
$reconfig['image_library'] = 'gd2';
$reconfig['source_image'] = './uploads/'.$file_name;
$reconfig['maintain_ratio'] = True;
$reconfig['width'] = 600;
$reconfig['height'] = 600;

$this->load->library('image_lib', $reconfig);

if ( !$this->image_lib->resize()){
echo $this->image_lib->display_errors();
$this->session->set_flashdata('message', $this->image_lib->display_errors('', ''));
return false;
}
else
{
return $file_name;
}
}

  }



public function editproduct(){
$id=$this->uri->segment(2);
 // echo $id;
 // exit;


$this->form_validation->set_rules('name','name','required|trim|xss_clean',array('required'=>'Please enter product name'));
$this->form_validation->set_rules('qty','qty','required|trim|xss_clean',array('required'=>'Please enter quantity'));


$this->form_validation->set_rules('unitprice','unitprice','required|trim|numeric|xss_clean',array('required'=>'Please enter unit price'));

$this->form_validation->set_rules('tax','tax','required|trim|xss_clean',array('required'=>'Please enter tax percentage'));


if($this->form_validation->run()==true){
// $this->load->library('image_lib');
// if(!empty($_FILES["image"]["name"]) )
// {
// $p1=$this->upload_file1('image');

// }
// else
// {
// $p1=$this->input->post('oldpic');
// }

$data=array(


      'prdt_name'=>$this->input->post('name'),
      'prdt_quantity'=>$this->input->post('qty'),
      'unit_price'=>$this->input->post('unitprice'),
      'tax_percentage'=>$this->input->post('tax'),

);

$ins=$this->Sitemodel->updatestore($data,$id);

// echo $ins;
// exit;

if($ins=="true"){


$dis['val']=$this->Sitemodel->display_data();
$this->load->view('header');
$this->load->view('view_product',$dis);
$this->load->view('footer');

}
else{
$data['product']=$this->Sitemodel->getstoreByID($id);

$this->load->view('header');
$this->load->view('editproduct',$data);
$this->load->view('footer');
}
}
else{
$data['product']=$this->Sitemodel->getstoreByID($id);

$this->load->view('header');
$this->load->view('editproduct',$data);
$this->load->view('footer');
}
}




public function del_data($id)
{

$id=$this->uri->segment(3);

// echo $id;
// exit;


$exe=$this->Sitemodel->delete_data($id);
if($exe)
{

$dis['val']=$this->Sitemodel->display_data();
$this->load->view('header');
$this->load->view('view_product',$dis);
$this->load->view('footer');

}  
}






public function login(){
    $this->form_validation->set_rules('email','Username','required');
    $this->form_validation->set_rules('password','Password','required');
    
    if($this->form_validation->run()==false){
      echo "false";
    }
    else{
      $username=$this->input->post('email');
      $password=$this->input->post('password');
      //check username and password //
    
      $count=$this->Sitemodel->checkusername_password($username,$password); 

 // echo $count;
 // exit;

      
      if($count>0){
        $re=$this->Sitemodel->loginuser($username,$password);//to set session
        

        if($re==true){  
           

      

$dis['val']=$this->Sitemodel->display_data();
$this->load->view('header');
$this->load->view('viewpage',$dis);
$this->load->view('footer');


        }  
      
        else{

           $this->session->set_flashdata('err_message', 'Sorry, your credentials are not valid, Please try again.');
           $this->load->view('loginpage');
        }
      }
      else{

           $this->session->set_flashdata('err_message', 'Sorry, your credentials are not valid, Please try again.');
           $this->load->view('loginpage');
      }
      
         
    }

}








}

?>
